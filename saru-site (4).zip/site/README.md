# $SARU website

Static site (plain HTML/CSS/JS, no build step). Works on GitHub Pages, Netlify, Vercel or any hosting.

- Edit `assets/js/config.js`: contract address (`ca`), socials, supply, tax. Pasting the CA turns on Copy and every Buy button.
- Stickers live in `stickers/<category>/`; the list the page reads is `stickers/manifest.js`.
- Open it through http(s) (`python3 -m http.server`) so PNG download and copy work.
- This is a meme coin made for entertainment. Not financial advice.
