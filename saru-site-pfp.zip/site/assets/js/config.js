/* Edit this file, then re-upload. That's all. */
window.SARU_CONFIG = {
  ticker: "$SARU",
  chain: "Solana",
  ca: "",            // paste contract address at launch: enables Copy + Buy buttons
  buyUrl: "",        // optional custom buy link (default: pump.fun/coin/<ca>)
  x: "https://x.com/SaruHQ_",
  tiktok: "https://www.tiktok.com/@saru4943",
  telegram: "",      // "" hides the button
  supply: "1,000,000,000",
  tax: "0%"
};
