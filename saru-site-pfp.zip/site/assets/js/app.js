(()=>{
const C=window.SARU_CONFIG,S=window.SARU_STICKERS,$=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const by=c=>S.filter(s=>s.cat===c),find=n=>S.find(s=>s.name===n),rnd=a=>a[Math.floor(Math.random()*a.length)];
const shuf=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
const el=(t,p={},k=[])=>Object.assign(document.createElement(t),p);
/* config */
const buy=C.buyUrl||(C.ca?'https://pump.fun/coin/'+C.ca:'');
$$('[data-buy]').forEach(a=>{if(buy){a.href=buy;a.target='_blank';a.rel='noopener'}else if(a.closest('#buy')){a.textContent='Launching soon';a.setAttribute('aria-disabled','true');a.removeAttribute('href')}});
$$('[data-x]').forEach(a=>a.href=C.x);
$$('[data-tt]').forEach(a=>{if(C.tiktok)a.href=C.tiktok;else a.remove()});
$$('[data-f]').forEach(n=>{if(C[n.dataset.f])n.textContent=C[n.dataset.f]});
if(C.telegram)$('.nav-cta').prepend(el('a',{className:'btn sm ghost',href:C.telegram,textContent:'TG',target:'_blank',rel:'noopener'}));
if(C.ca){$('#caVal').textContent=C.ca;const b=$('#caCopy');b.disabled=false;b.onclick=()=>navigator.clipboard.writeText(C.ca).then(()=>{b.textContent='Copied!';setTimeout(()=>b.textContent='Copy',1400)})}
$('#burger').onclick=e=>{const o=$('#links').classList.toggle('open');e.currentTarget.setAttribute('aria-expanded',o)};
$$('#links a').forEach(a=>a.onclick=()=>$('#links').classList.remove('open'));
const tk=['NO KOL','NO ROADMAP','NO UTILITY','JUST A MONKEY WITH A BOW','NEVER SELL THE BOW','HODL (WITH FEELINGS)','WEN MOON','SEND A STICKER'];
$('#ticker').innerHTML=[...tk,...tk].map(t=>`<span>${t}</span><i>✿</i>`).join('');

/* mood meter */
const Z=[{m:20,t:'REKT',p:['4-08','4-09','4-13','4-20','4-24','4-12']},{m:40,t:'PANIC SELL',p:['1-09','1-10','1-19','3-56','4-16']},{m:60,t:'COPING',p:['1-11','1-29','3-55','1-36','1-22']},{m:80,t:'HODL',p:['1-12','3-06','2-38','1-05','3-19']},{m:101,t:'TO THE MOON',p:['1-13','3-04','3-16','4-07','2-26','3-17']}]
 .map(z=>({...z,p:z.p.map(find).filter(Boolean)}));
const rg=$('#mRange'),img=$('#mImg'),svg=$('#mChart');let zi=-1,user=false;
const NS='http://www.w3.org/2000/svg',N=26;
const noise=i=>Math.sin(i*12.9898)*43758.5453%1;
function chart(v){const e=v/100,pts=[];let prev=.5;svg.innerHTML='';
 for(let i=1;i<=N;i++){const t=i/N,c=Math.min(.96,Math.max(.04,.5+(e-.5)*Math.pow(t,1.4)+noise(i)*.07));pts.push([prev,c]);prev=c}
 const w=600/N,Y=p=>250-p*236;
 pts.forEach(([o,c],i)=>{const x=i*w+w/2,hi=Math.max(o,c)+.025+Math.abs(noise(i+9))*.03,lo=Math.min(o,c)-.025-Math.abs(noise(i+5))*.03,col=c>=o?'#5cc23a':'#e3242b';
  const l=document.createElementNS(NS,'line');l.setAttribute('x1',x);l.setAttribute('x2',x);l.setAttribute('y1',Y(hi));l.setAttribute('y2',Y(lo));l.setAttribute('stroke','#3b1f12');l.setAttribute('stroke-width',3);svg.append(l);
  const r=document.createElementNS(NS,'rect');r.setAttribute('x',x-w*.34);r.setAttribute('width',w*.68);r.setAttribute('y',Y(Math.max(o,c)));r.setAttribute('height',Math.max(5,Math.abs(Y(o)-Y(c))));r.setAttribute('fill',col);r.setAttribute('stroke','#3b1f12');r.setAttribute('stroke-width',3);r.setAttribute('rx',3);svg.append(r)})}
function setMeter(v){v=+v;const z=Z.findIndex(z=>v<z.m);
 let txt,neg=false;if(v<50){txt='-'+Math.round(99-v/50*99)+'%';neg=true}else{const m=1+Math.pow((v-50)/50,2)*999;txt=m<10?'+'+Math.round((m-1)*100)+'%':Math.round(m)+'x'}
 $('#mPct').textContent=txt;$('#mPct').classList.toggle('neg',neg);chart(v);
 if(z!==zi){zi=z;$('#mMood').textContent=Z[z].t;const s=rnd(Z[z].p);img.src=s.src;img.classList.remove('pop');void img.offsetWidth;img.classList.add('pop')}}
rg.addEventListener('input',()=>{user=true;setMeter(rg.value)});
img.onclick=()=>{const s=rnd(Z[zi].p);img.src=s.src;img.classList.remove('pop');void img.offsetWidth;img.classList.add('pop')};
if(reduce){setMeter(100)}else{setMeter(0);rg.value=0;const t0=performance.now();(function f(t){if(user)return;const k=Math.min(1,(t-t0-500)/3200);if(k>0){const e=1-Math.pow(1-k,3);rg.value=e*100;setMeter(rg.value)}if(k<1)requestAnimationFrame(f)})(t0)}

/* vault */
const CATS=[['all','All'],['trader','Trader'],['rekt','Rekt'],['moods','Moods'],['costumes','Costumes'],['halloween','Halloween'],['christmas','Christmas'],['couples','Couples']];
const vault=S.filter(s=>CATS.some(c=>c[0]===s.cat));let cat='all',shown=36,all=shuf(vault),list=[],li=0;
$('#vCount').textContent=S.length;
const pool=()=>cat==='all'?all:by(cat);
function tabs(){const t=$('#tabs');t.innerHTML='';CATS.forEach(([k,n])=>{const b=el('button',{innerHTML:n+'<small>'+(k==='all'?vault.length:by(k).length)+'</small>',type:'button'});b.className=k===cat?'on':'';b.onclick=()=>{cat=k;shown=36;tabs();grid()};t.append(b)})}
function grid(){const g=$('#grid'),p=pool();g.innerHTML='';p.slice(0,shown).forEach((s,i)=>{const c=el('button',{className:'card',type:'button'});c.setAttribute('aria-label','Open sticker');c.append(el('img',{src:s.src,alt:'Saru sticker',loading:'lazy',width:150,height:150}));c.onclick=()=>open(p,i);g.append(c)});$('#more').style.display=shown<p.length?'':'none'}
$('#more').onclick=()=>{shown+=48;grid()};$('#shuffle').onclick=()=>{all=shuf(vault);shown=36;grid()};
$$('[data-tab]').forEach(a=>a.addEventListener('click',()=>{cat=a.dataset.tab;shown=36;tabs();grid()}));
tabs();grid();

/* lightbox */
const lb=$('#lb');
function open(l,i){list=l;li=i;show();lb.showModal()}
function show(){const s=list[li];$('#lbImg').src=s.src;$('#lbNote').textContent='';$('#lbPf').hidden=!s.theme;$('#lbMk').hidden=!!s.theme}
$('#lbX').onclick=()=>lb.close();lb.onclick=e=>{if(e.target===lb)lb.close()};
$('#lbP').onclick=()=>{li=(li+list.length-1)%list.length;show()};$('#lbN').onclick=()=>{li=(li+1)%list.length;show()};
lb.addEventListener('keydown',e=>{if(e.key==='ArrowLeft')$('#lbP').click();if(e.key==='ArrowRight')$('#lbN').click()});
function toCanvas(src){return new Promise((ok,no)=>{const i=new Image();i.onload=()=>{const c=el('canvas',{width:i.naturalWidth,height:i.naturalHeight});c.getContext('2d').drawImage(i,0,0);ok(c)};i.onerror=no;i.src=src})}
const blob=c=>new Promise(r=>c.toBlob(r,'image/png'));
async function dl(c,name,note){try{const b=await blob(c),a=el('a',{href:URL.createObjectURL(b),download:name});a.click();note.textContent='Saved. Go reply to somebody.'}catch(e){note.textContent='Open the site over http(s) to export PNGs.'}}
async function cp(c,note){try{await navigator.clipboard.write([new ClipboardItem({'image/png':blob(c)})]);note.textContent='Copied. Paste it anywhere.'}catch(e){note.textContent='Copy is not supported here. Use Download.'}}
$('#lbDl').onclick=async()=>{const s=list[li];try{dl(await toCanvas(s.src),'saru-'+s.name+'.png',$('#lbNote'))}catch(e){$('#lbNote').textContent='Open the site over http(s) to export PNGs.'}};
$('#lbCp').onclick=async()=>{try{cp(await toCanvas(list[li].src),$('#lbNote'))}catch(e){$('#lbNote').textContent='Open the site over http(s) to copy.'}};
$('#lbMk').onclick=()=>{lb.close();pickSticker(list[li]);$('#maker').scrollIntoView()};

/* parade, love, scenes */
const strip=$('#strip');shuf(by('halloween')).forEach((s,i,a)=>{const m=el('img',{src:s.src,alt:'Saru in a Halloween costume',loading:'lazy',height:210});m.onclick=()=>open(a,i);strip.append(m)});
let dn=false,sx=0,sl=0;strip.onpointerdown=e=>{if(e.pointerType==='mouse'){dn=true;sx=e.clientX;sl=strip.scrollLeft}};addEventListener('pointerup',()=>dn=false);strip.onpointermove=e=>{if(dn)strip.scrollLeft=sl-(e.clientX-sx)};
shuf(by('couples')).slice(0,6).forEach(s=>$('#duo').append(el('img',{src:s.src,alt:'Saru and her monkey',loading:'lazy'})));


/* PFP pack */
const P=window.SARU_PFPS||[];
const TH=[['all','All'],['frog','🐸 Frog Pond'],['fox','🍂 Autumn Fox'],['bunny','🐰 Bunny Meadow'],['mouse','🐭 Mouse Pantry'],['panda','🐼 Panda Bamboo'],['cat','🐱 Cat Cafe'],['dog','🐶 Doggo Park'],['shark','🦈 Shark Reef'],['rain','🌧️ Rainy Frog']];
const pby=t=>t==='all'?P:P.filter(p=>p.theme===t);let pt='all';
$('#pfCount').textContent=P.length;
function pfTabs(){const t=$('#pfTabs');t.innerHTML='';TH.forEach(([k,n])=>{const b=el('button',{type:'button',innerHTML:n+'<small>'+pby(k).length+'</small>'});b.className=k===pt?'on':'';b.onclick=()=>{pt=k;pfTabs();pfGrid()};t.append(b)})}
function pfGrid(){const g=$('#pfGrid'),l=pby(pt);g.innerHTML='';l.forEach((s,i)=>{const c=el('button',{className:'pfcard',type:'button'});c.setAttribute('aria-label','Open PFP '+s.name);c.append(el('img',{src:s.src,alt:'Saru PFP '+s.name,loading:'lazy',width:256,height:256}));const d=el('span',{className:'pfdot'});d.append(el('img',{src:s.src,alt:''}));c.append(d);c.onclick=()=>open(l,i);g.append(c)})}
pfTabs();pfGrid();

/* PFP simulator */
const sim={p:P[0],app:'instagram',z:1};
const esc=t=>String(t).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const oth=n=>{const i=Math.max(0,P.indexOf(sim.p));return Array.from({length:n},(_,k)=>P[(i+7*(k+1)+k*3)%P.length])};
const AV=(p,z,cls='')=>`<span class="av ${cls}"><img src="${p.src}" alt="" style="transform:scale(${z})"></span>`;
function render(){
 const n=esc($('#simName').value||'Saru'),u=esc(($('#simUser').value||'saru_hq').replace(/^@/,'')),bio=esc($('#simBio').value),z=sim.z,me=AV(sim.p,z),o=oth(9);
 let h='';
 if(sim.app==='instagram'){
  h=`<div class="ig"><div class="ig-top"><b>${u} <i>⌄</i></b><span>＋ ☰</span></div>
  <div class="ig-head"><span class="ring">${AV(sim.p,z)}</span><div class="ig-stats"><div><b>54</b>posts</div><div><b>12.4K</b>followers</div><div><b>69</b>following</div></div></div>
  <div class="ig-bio"><b>${n}</b><br>${bio}</div>
  <div class="ig-btns"><span class="b blue">Follow</span><span class="b">Message</span></div>
  <div class="ig-hl">${o.slice(0,4).map((p,i)=>`<div>${AV(p,1,'sm')}<small>${['gm','pump','dip','hodl'][i]}</small></div>`).join('')}</div>
  <div class="ig-grid">${o.slice(0,9).map(p=>`<img src="${p.src}" alt="">`).join('')}</div></div>`;
 }else if(sim.app==='tiktok'){
  h=`<div class="tt"><div class="tt-top"><span>＋</span><b>${n}</b><span>☰</span></div>
  <div class="tt-prof">${AV(sim.p,z,'lg')}<b>@${u}</b>
  <div class="tt-stats"><div><b>69</b>Following</div><div><b>69.4K</b>Followers</div><div><b>420K</b>Likes</div></div>
  <div class="tt-btns"><span class="b red">Follow</span><span class="b">▾</span></div><p>${bio}</p></div>
  <div class="tt-tabs"><b>▥</b><span>♡</span><span>🔒</span></div>
  <div class="tt-grid">${o.slice(0,6).map((p,i)=>`<div><img src="${p.src}" alt=""><small>▷ ${(i*37+12)%90+10}K</small></div>`).join('')}</div></div>`;
 }else if(sim.app==='x'){
  h=`<div class="xx"><div class="x-ban"></div><div class="x-row">${AV(sim.p,z,'xl')}<span class="b">Follow</span></div>
  <div class="x-id"><b>${n}</b><small>@${u}</small></div><p>${bio}</p>
  <div class="x-meta"><span><b>69</b> Following</span><span><b>12.4K</b> Followers</span></div>
  <div class="x-tabs"><b>Posts</b><span>Replies</span><span>Media</span></div>
  <div class="x-post">${AV(sim.p,z,'md')}<div><b>${n}</b> <small>@${u} · 2h</small><p>gm. the chart is red and the bow is still on.</p><small class="ic">💬 69 &nbsp; ⟲ 420 &nbsp; ♡ 9.0K</small></div></div>
  <div class="x-post">${AV(sim.p,z,'md')}<div><b>${n}</b> <small>@${u} · 5h</small><p>never sell the bow.</p><small class="ic">💬 12 &nbsp; ⟲ 88 &nbsp; ♡ 1.2K</small></div></div></div>`;
 }else{
  const rows=[['Mama','Dont forget to eat 🍚','10:42'],['Bro','wen moon??','09:15'],['Gym Group','Sticker','Yesterday'],['Cousin','lol send the monkey','Yesterday']];
  h=`<div class="wa"><div class="wa-top"><b>WhatsApp</b><span>📷 ⋮</span></div>
  <div class="wa-tabs"><b>Chats</b><span>Updates</span><span>Calls</span></div>
  <div class="wa-prof">${AV(sim.p,z,'xl')}<div><b>${n}</b><small>${bio}</small></div></div>
  <div class="wa-list"><div class="wa-r">${AV(sim.p,z,'md')}<div><b>${n}</b><small>✓✓ you: send a sticker</small></div><i>11:20</i></div>
  ${rows.map((r,i)=>`<div class="wa-r">${AV(o[i],1,'md')}<div><b>${r[0]}</b><small>${r[1]}</small></div><i>${r[2]}</i></div>`).join('')}</div></div>`;
 }
 $('#screen').innerHTML=h;$('#phone').dataset.app=sim.app;
}
function simPick(){const p=$('#simPick'),t=$('#simTheme').value;p.innerHTML='';pby(t).forEach(s=>{const b=el('button',{type:'button'});b.dataset.n=s.name;b.append(el('img',{src:s.src,alt:'',loading:'lazy'}));b.onclick=()=>setPfp(s,true);p.append(b)});mark()}
function mark(){$$('#simPick button').forEach(b=>b.classList.toggle('on',b.dataset.n===sim.p.name))}
function setPfp(s,stay){sim.p=s;mark();render();if(!stay)$('#sim').scrollIntoView()}
TH.forEach(([k,n])=>$('#simTheme').append(el('option',{value:k,textContent:n==='All'?'All themes':n})));
$('#simTheme').onchange=simPick;
$$('#simApps button').forEach(b=>b.onclick=()=>{$$('#simApps button').forEach(x=>x.classList.remove('on'));b.classList.add('on');sim.app=b.dataset.app;render()});
['simName','simUser','simBio'].forEach(i=>$('#'+i).addEventListener('input',render));
$('#simZoom').addEventListener('input',e=>{sim.z=e.target.value/100;render()});
$('#simDark').onchange=e=>$('#phone').classList.toggle('dark',e.target.checked);
function pfpCanvas(round){return new Promise((ok,no)=>{const i=new Image();i.onload=()=>{const S=512,c=el('canvas',{width:S,height:S}),x=c.getContext('2d');if(round){x.beginPath();x.arc(S/2,S/2,S/2,0,7);x.clip()}const w=S*sim.z;x.drawImage(i,(S-w)/2,(S-w)/2,w,w);ok(c)};i.onerror=no;i.src=sim.p.src})}
$('#simDl').onclick=async()=>{try{dl(await pfpCanvas(true),'saru-pfp-round-'+sim.p.name+'.png',$('#simNote'))}catch(e){$('#simNote').textContent='Open the site over http(s) to export PNGs.'}};
$('#simDlSq').onclick=async()=>{try{dl(await pfpCanvas(false),'saru-pfp-'+sim.p.name+'.png',$('#simNote'))}catch(e){$('#simNote').textContent='Open the site over http(s) to export PNGs.'}};
$('#lbPf').onclick=()=>{lb.close();setPfp(list[li])};
simPick();render();

/* maker */
const cv=$('#cv'),cx=cv.getContext('2d');let mk={s:find('1-12')||vault[0],bg:'sun',im:null};
const BG={sun:c=>{const g=c.createLinearGradient(0,0,0,1000);g.addColorStop(0,'#ffd23f');g.addColorStop(1,'#ff8db8');return g},sky:()=>'#bfe0ff',grass:()=>'#bdf08a',night:()=>'#2a2766',white:()=>'#fff'};
function draw(){cx.clearRect(0,0,1000,1000);if(mk.bg!=='clear'){cx.fillStyle=BG[mk.bg](cx);cx.fillRect(0,0,1000,1000)}
 if(mk.im&&mk.im.complete){const sz=$('#mkS').value*10,r=Math.min(sz/mk.im.naturalWidth,sz/mk.im.naturalHeight);const w=mk.im.naturalWidth*r,h=mk.im.naturalHeight*r;cx.drawImage(mk.im,(1000-w)/2,(1000-h)/2+20,w,h)}
 const txt=(t,y)=>{t=t.toUpperCase();let f=110;cx.font=`900 ${f}px Grandstander,Trebuchet MS,sans-serif`;while(cx.measureText(t).width>920&&f>30){f-=4;cx.font=`900 ${f}px Grandstander,Trebuchet MS,sans-serif`}
  cx.textAlign='center';cx.textBaseline='middle';cx.lineJoin='round';cx.lineWidth=f/5;cx.strokeStyle='#3b1f12';cx.strokeText(t,500,y);cx.fillStyle='#fff';cx.fillText(t,500,y)};
 txt($('#mkT').value,95);txt($('#mkB').value,905)}
function pickSticker(s){mk.s=s;mk.im=new Image();mk.im.onload=draw;mk.im.src=s.src;$$('#mkPick button').forEach(b=>b.classList.toggle('on',b.dataset.n===s.name))}
const mc=$('#mkCat');CATS.slice(1).forEach(([k,n])=>mc.append(el('option',{value:k,textContent:n})));mc.value='trader';
function picker(){const p=$('#mkPick');p.innerHTML='';by(mc.value).slice(0,90).forEach(s=>{const b=el('button',{type:'button'});b.dataset.n=s.name;b.append(el('img',{src:s.src,alt:'',loading:'lazy'}));b.onclick=()=>pickSticker(s);p.append(b)});$$('#mkPick button').forEach(b=>b.classList.toggle('on',b.dataset.n===mk.s.name))}
mc.onchange=picker;picker();pickSticker(mk.s);
['mkT','mkB','mkS'].forEach(i=>$('#'+i).addEventListener('input',draw));
$$('#mkBg button').forEach(b=>b.onclick=()=>{$$('#mkBg button').forEach(x=>x.classList.remove('on'));b.classList.add('on');mk.bg=b.dataset.bg;draw()});
const caps=[['ME WATCHING THE CHART','BUT MAKE IT CUTE'],['BOUGHT THE TOP','FEELING THE FEELINGS'],['IT IS JUST A DIP','TRUST ME'],['WHEN THE CANDLE GOES GREEN','SEND STICKER'],['WIFE: WHAT DID YOU BUY?','SARU: $SARU']];
$('#mkRnd').onclick=()=>{mc.value=rnd(CATS.slice(1))[0];picker();pickSticker(rnd(by(mc.value)));const c=rnd(caps);$('#mkT').value=c[0];$('#mkB').value=c[1];const b=rnd($$('#mkBg button').slice(0,5));b.click()};
$('#mkDl').onclick=()=>dl(cv,'saru-meme.png',$('#mkNote'));$('#mkCp').onclick=()=>cp(cv,$('#mkNote'));
document.fonts&&document.fonts.ready.then(draw);
})();
