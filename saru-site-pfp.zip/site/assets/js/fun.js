(()=>{
const S=window.SARU_STICKERS;if(!S)return;
const $=s=>document.querySelector(s),rnd=a=>a[Math.floor(Math.random()*a.length)],R=(a,b)=>a+Math.random()*(b-a);
const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
const by=c=>S.filter(s=>s.cat===c),find=n=>S.find(s=>s.name===n),pick=l=>l.map(find).filter(Boolean);
const fun=S.filter(s=>['trader','moods','costumes','couples','christmas','halloween'].includes(s.cat));
const el=(t,c,p={})=>Object.assign(document.createElement(t),{className:c||''},p);
const fx=el('div','fx');document.body.append(fx);const tz=el('div','toasts');document.body.append(tz);let live=0;
const ROCK=pick(['1-13','3-04','3-16','4-07','2-26','3-17','2-37']);
/* ---------- effects ---------- */
function fly(src,size,x,y,kf,dur,ease='ease-in'){if(reduce||live>90)return;live++;const i=el('img','fxi',{src,alt:'',width:size,height:size});i.style.cssText=`left:${x}px;top:${y}px;width:${size}px`;fx.append(i);i.animate(kf,{duration:dur,easing:ease,fill:'forwards'}).onfinish=()=>{i.remove();live--}}
function rain(n=30,up=false,list=fun){for(let k=0;k<n;k++)setTimeout(()=>{const s=rnd(list),z=R(60,120),H=innerHeight;
 fly(s.src,z,R(0,innerWidth-z),up?H+40:-140,[{transform:'translateY(0) rotate(0)'},{transform:`translateY(${up?-(H+260):H+260}px) rotate(${R(-360,360)}deg)`}],R(2200,4200),up?'ease-out':'ease-in')},k*55)}
function burst(x,y,n=14,z=70){for(let k=0;k<n;k++){const a=k/n*6.283+R(-.2,.2),d=R(120,260),dx=Math.cos(a)*d,dy=Math.sin(a)*d;
 fly(rnd(fun).src,z,x-z/2,y-z/2,[{transform:'translate(0,0) scale(.3)',opacity:1},{transform:`translate(${dx}px,${dy}px) scale(1) rotate(${R(-200,200)}deg)`,opacity:1,offset:.55},{transform:`translate(${dx}px,${dy+220}px) scale(.8)`,opacity:0}],1300,'ease-out')}}
function toast(m){const t=el('div','toast',{textContent:m});tz.append(t);setTimeout(()=>t.remove(),2900)}
function overlay(cls,html,ms){const o=el('div','ov '+cls,{innerHTML:html});document.body.append(o);setTimeout(()=>{o.classList.add('bye');setTimeout(()=>o.remove(),500)},ms);return o}
/* ---------- secrets ---------- */
const E={logo:'Letter salad',moon:'Wen moon? Now.',rug:'Rug pull survivor',konami:'Old-school monkey',peek:'Caught her peeking',ball:'Took advice from a monkey'};
let found=[];try{found=JSON.parse(localStorage.getItem('saruSecrets')||'[]')}catch(e){}
const bdg=el('button','badge',{type:'button',hidden:true});document.body.append(bdg);
function badge(){bdg.hidden=!found.length;bdg.textContent='🍌 '+found.length+'/6'}
bdg.onclick=()=>toast('Keep poking. The logo, the keyboard, and anything that moves.');badge();
function secret(k){if(found.includes(k))return;found.push(k);try{localStorage.setItem('saruSecrets',JSON.stringify(found))}catch(e){}badge();toast(`🍌 Secret ${found.length}/6: ${E[k]}`);if(found.length===6)setTimeout(win,1300)}
function win(){rain(70);const t=encodeURIComponent('I found all 6 of Saru’s secrets 🍌🎀 $SARU @SaruHQ_ '+location.href);
 const o=overlay('win',`<div class="wc"><img src="assets/img/saru.webp" alt="" width="200"><h2>All 6 secrets!</h2><p>You are officially a true Saru. Screenshot this and tag her.</p><a class="btn red" target="_blank" rel="noopener" href="https://twitter.com/intent/tweet?text=${t}">Share on 𝕏</a> <button class="btn ghost" type="button">Close</button></div>`,60000);o.querySelector('button').onclick=()=>o.remove()}
/* ---------- logo ---------- */
const logo=$('.logo');let lc=0;
if(logo){logo.style.cursor='pointer';logo.addEventListener('click',e=>{const sp=e.target.closest('span');if(sp){sp.classList.remove('jig');void sp.offsetWidth;sp.classList.add('jig')}burst(e.clientX,e.clientY,10);if(++lc===5){rain(30);secret('logo')}})}
/* ---------- keyboard secrets ---------- */
let buf='',kk=[];const KON='ArrowUp,ArrowUp,ArrowDown,ArrowDown,ArrowLeft,ArrowRight,ArrowLeft,ArrowRight,b,a';
function moon(){overlay('moon','<h2>WEN MOON? NOW.</h2>',2600);rain(40,true,ROCK.length?ROCK:fun);secret('moon')}
function rug(){const m=$('main');m&&m.classList.add('shake');setTimeout(()=>m&&m.classList.remove('shake'),700);
 const o=overlay('rug',`<img src="${find('4-08')?.src||''}" alt=""><h2>RUG PULLED</h2>`,3900);
 setTimeout(()=>{o.innerHTML=`<img src="${find('1-12')?.src||''}" alt=""><h2>jk. we’re fine.</h2><p>(sorry)</p>`},2200);secret('rug')}
addEventListener('keydown',e=>{if(/INPUT|TEXTAREA|SELECT/.test(e.target.tagName))return;
 buf=(buf+(e.key.length===1?e.key.toLowerCase():'')).slice(-8);
 if(buf.endsWith('moon')){buf='';moon()}else if(buf.endsWith('rug')){buf='';rug()}else if(buf.endsWith('wagmi')){buf='';rain(40);toast('WAGMI 🎀')}else if(buf.endsWith('banana')){buf='';rain(40,false,by('costumes'));toast('🍌🍌🍌')}
 kk=[...kk,e.key.length===1?e.key.toLowerCase():e.key].slice(-10);
 if(kk.join()===KON){kk=[];fly('assets/img/saru.webp',380,innerWidth/2-190,innerHeight/2-190,[{transform:'scale(0) rotate(0)'},{transform:'scale(1.2) rotate(360deg)',offset:.5},{transform:'scale(0) rotate(720deg)'}],2200,'ease-in-out');rain(45);secret('konami')}});
const fa=$('.foot img');let ft=0;if(fa)fa.addEventListener('click',()=>{if(++ft===3){ft=0;rug()}});
/* ---------- peeking Saru ---------- */
const LINES=['psst. buy the dip.','ooh ooh aah aah','did someone say banana?','i am not a financial advisor. i am a monkey.','my bow is not for sale.','check the chart. no wait, don’t.','sorry, was i supposed to be hiding?','nice wallet. is that a rug?','touch grass. then touch me.'];
const pk=el('div','peek',{innerHTML:'<div class="bub"></div><img alt="" width="130" height="130">'});pk.setAttribute('aria-hidden','true');document.body.append(pk);
const pi=pk.querySelector('img'),pb=pk.querySelector('.bub');let hide;
function peek(){const s=rnd(by('moods').concat(by('trader')));pi.src=s.src;pb.textContent=rnd(LINES);pk.style.left=R(8,Math.max(10,(innerWidth-170)/innerWidth*100))+'%';pk.classList.add('in');clearTimeout(hide);hide=setTimeout(()=>pk.classList.remove('in'),4500)}
pk.onclick=e=>{burst(e.clientX,e.clientY,12);rain(18);pb.textContent='ooh ooh aah aah!';secret('peek')};
(function loop(){setTimeout(()=>{if(!document.hidden&&!$('dialog[open]'))peek();loop()},R(22000,42000))})();setTimeout(peek,9000);
/* ---------- hero floaters ---------- */
const fl=$('#floaters');if(fl){const P=[[1,10,84],[44,3,70],[90,8,90],[46,82,76],[2,70,96],[93,76,80]];let pops=0;
 P.forEach(([x,y,z],i)=>{const f=el('img','fl',{src:rnd(fun).src,alt:'',width:z,height:z});f.style.cssText=`left:${x}%;top:${y}%;--s:${z}px;--d:${R(2.4,4.2).toFixed(1)}s;animation-delay:-${R(0,3).toFixed(1)}s`;
  f.onclick=e=>{burst(e.clientX,e.clientY,8,56);f.classList.add('pop');if(++pops===12)toast('you really like popping monkeys huh');setTimeout(()=>{f.src=rnd(fun).src;f.classList.remove('pop')},1100)};fl.append(f)})}
/* ---------- Ask Saru ---------- */
const AN={p:{i:pick(['1-13','3-04','3-16','4-07','2-26','3-17','1-00']),t:['Moon? Soon™.','Yes. Immediately. Do not ask how I know.','Green candles incoming. I can smell bananas.','WAGMI. Probably. Maybe. Yes.']},
 n:{i:pick(['4-08','4-09','1-10','1-19','4-24','4-13']),t:['Bro… no.','Down 99%. But still cute.','Sell. Wait. Buy. Wait. Sell. I’m confused.','I would not. But I would also fully do it.']},
 m:{i:pick(['1-11','1-29','3-55','1-36','1-22','3-35']),t:['Ask again after a nap.','Just HODL and touch grass.','I’m a monkey. Why are you asking me?','Banana first, questions later.','NFA. Not even a financial animal.']}};
const af=$('#askF');if(af){const oi=$('#orImg'),ot=$('#orTxt');oi.src=find('1-22')?.src||'';
 af.onsubmit=e=>{e.preventDefault();const q=$('#askQ').value.trim();oi.classList.remove('shake');void oi.offsetWidth;oi.classList.add('shake');
  if(!q){ot.textContent='Ask me something first. I’m waiting. 🍌';return}
  const k=rnd(['p','m','n','m','p']),a=AN[k];ot.textContent='…';setTimeout(()=>{oi.src=rnd(a.i).src;ot.textContent=rnd(a.t);if(k==='p')rain(14,true,ROCK.length?ROCK:fun)},550);secret('ball')}}
/* ---------- stats count-up ---------- */
const io=new IntersectionObserver(es=>es.forEach(en=>{if(!en.isIntersecting)return;io.unobserve(en.target);const b=en.target,n=+b.dataset.n;if(!n||reduce){b.textContent=n.toLocaleString();return}const t0=performance.now();(function f(t){const k=Math.min(1,(t-t0)/1500);b.textContent=Math.round(n*(1-Math.pow(1-k,3))).toLocaleString();if(k<1)requestAnimationFrame(f)})(t0)}),{threshold:.6});
document.querySelectorAll('[data-n]').forEach(b=>io.observe(b));
/* ---------- rocket progress ---------- */
const nav=$('.nav');if(nav&&ROCK.length){const p=el('div','prog',{innerHTML:`<i></i><img alt="" src="${find('3-16')?.src||ROCK[0].src}" width="54" height="54">`});nav.append(p);const bar=p.firstChild,rk=p.lastChild;
 const up=()=>{const m=document.documentElement.scrollHeight-innerHeight,k=m>0?scrollY/m:0;bar.style.width=k*100+'%';rk.style.left=k*100+'%'};addEventListener('scroll',up,{passive:true});up()}
/* ---------- tiny surprises ---------- */
document.addEventListener('click',e=>{if(e.target.closest('[aria-disabled=true]'))toast('Not yet! Saru is still putting on her bow 🎀')});
const T=document.title;document.addEventListener('visibilitychange',()=>{document.title=document.hidden?'🥺 don’t leave me':T});
console.log('%c SARU 🎀 ','background:#e3242b;color:#fff;font:900 28px sans-serif;border-radius:8px','\npsst… try typing: moon, rug, wagmi, banana. There are 6 secrets.');
/* ---------- splash ---------- */
const sp=$('#splash');if(sp){let seen=0;try{seen=sessionStorage.getItem('saruSplash')}catch(e){}if(reduce||seen)sp.remove();else{try{sessionStorage.setItem('saruSplash',1)}catch(e){}const go=()=>{sp.classList.add('out');setTimeout(()=>sp.remove(),700)};setTimeout(go,1000);sp.onclick=go}}
})();
